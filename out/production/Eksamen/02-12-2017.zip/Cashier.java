public class Cashier  extends Employee{
   /*
   *Denne class repræsenterer "Kasserer"
   *
   *
   *
   */


    //Fields

    //Constructor
    public Cashier(String firstName, String lastName, String adress, int phoneNumber){
        super("Cashier",firstName,lastName,adress,phoneNumber);
    }

    //Overloaded constructors

    //Getters

    //Setters

}
