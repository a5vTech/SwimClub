public class Manager extends Employee {
    //Fields

    //Constructor
    public Manager(String firstName, String lastName, String address, int phoneNumber) {
        super("Manager", firstName, lastName, address, phoneNumber);
    }
    //Overloaded constructors

    //Override


    //Getters


    //Setters

}
